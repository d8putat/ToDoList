﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using ToDoList.Interfaces;
using ToDoList.Models;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Specialized;

namespace ToDoList.Services
{
    public class TaskService : ITaskService
    {
        private readonly string _jsonTasksFileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "tasks.json");
        private string _stringTasks { get; set; }
        public ObservableCollection<ToDoTask> _tasks { get; set; } = new ObservableCollection<ToDoTask>();
        public ObservableCollection<ToDoTask> GetAllTasks()
        {
            return _tasks;
        }

        public TaskService()
        {
            _stringTasks = ReadData();
            if (_stringTasks != "")
                _tasks = JsonConvert.DeserializeObject<ObservableCollection<ToDoTask>>(_stringTasks);
            _tasks.CollectionChanged += ReWriteData;
        }

        private void ReWriteData(object sender, NotifyCollectionChangedEventArgs e)
        {
            var tasks = JsonConvert.SerializeObject(_tasks);
            using (var stream = new FileStream(_jsonTasksFileName, FileMode.Truncate))
            {
                using (var streamWriter = new StreamWriter(stream))
                {
                    streamWriter.WriteLine(tasks);
                }
            }
        }

        private string ReadData()
        {
            using (var stream = new FileStream(_jsonTasksFileName, FileMode.OpenOrCreate))
            {
                using (var streamReader = new StreamReader(stream))
                {
                    return streamReader.ReadToEnd();
                }
            }
        }
        public void SaveTaskInDatabase(ToDoTask newTask)
        {
            _tasks.Add(newTask);
        }

        public void DeleteTaskFromDatabase(ToDoTask removableTask)
        {
            _tasks.RemoveAt(_tasks.IndexOf(removableTask));
        }

        public void EditStateTask(ToDoTask editTask)
        {
            DeleteTaskFromDatabase(editTask);
            SaveTaskInDatabase(editTask);
        }
    }
}
